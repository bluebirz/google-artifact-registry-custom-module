def my_sum(int_list: list) -> int:
    print(f"sum of {int_list}")
    return sum(int_list)

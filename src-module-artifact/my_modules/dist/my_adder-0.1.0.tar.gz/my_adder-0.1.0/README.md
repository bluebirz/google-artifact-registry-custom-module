# Adder package

This is a sample package for Private repo in Google Artifact Registry
